package com.gestion_parqueadero.gestion_parqueadero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionParqueaderoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionParqueaderoApplication.class, args);
	}

}
