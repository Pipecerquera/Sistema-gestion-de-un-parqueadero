package com.gestion_parqueadero.gestion_parqueadero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionParqueaderoApplicationTests {

	@Test
	void contextLoads() {
	}

}
